-- true/false defn
FALSE = 0
TRUE = 1

-- condition return values
CONDITION_NOT_YET_MET = 0
CONDITION_SUCCEEDED = 1
CONDITION_FAILED = 2

-- Message types
MT_INFO = 0 
MT_ALERT = 1 

MSG_TOP = 1
MSG_VCENTRE = 2
MSG_BOTTOM = 4
MSG_LEFT = 8
MSG_CENTRE = 16
MSG_RIGHT = 32

MSG_SMALL = 0
MSG_REG = 1
MSG_LRG = 2

-- scenario-exclusive variables
rs1 = nil
rs2 = nil
rs3 = nil

function DisplayRecordedMessage( messageName )
  SysCall("RegisterRecordedMessage", "StartDisplay" .. messageName,  
      "StopDisplay" .. messageName, 1);
end

function StartDisplay1Text()
	if rs1 == true then
		SysCall ( "ScenarioManager:ShowInfoMessageExt", "Request Stop",  
			"1.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
	end
end

function StopDisplay1Text()
end

function StartDisplay2Text()
	if rs2 == true then
		SysCall ( "ScenarioManager:ShowInfoMessageExt", "Request Stop",  
			"2.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
	end
end

function StopDisplay2Text()
end

function StartDisplay3Text()
	if rs3 == true then
		SysCall ( "ScenarioManager:ShowInfoMessageExt", "Request Stop",  
			"3.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
	end
end

function StopDisplay2Text()
end

function StartDisplayTrueText()
	SysCall ( "ScenarioManager:ShowInfoMessageExt", "Request Stop",  
		"debug-true.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
end

function StopDisplayTrueText()
end

function StartDisplayFalseText()
	SysCall ( "ScenarioManager:ShowInfoMessageExt", "Request Stop",  
		"debug-false.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
end

function StopDisplayFalseText()
end

function OnEvent(event)
  if (event == "init") then
  -- this just assigns all the random variables and stuff like that
	-- 50% chance of calling at any of these stations
	rs1 = (math.random(0,1) == 1)
	rs2 = (math.random(0,1) == 1)
	rs3 = (math.random(0,1) == 1)
  end
  
  -- Llanfairfechan
  if (event == "RS1") then
	if rs1 == true then
		DisplayRecordedMessage("1Text");
	end
  end
  
  -- Penmaenmawr
  if (event == "RS2") then
    if rs2 == true then
		DisplayRecordedMessage("2Text");
	end
  end
  
  -- Conwy
  if (event == "RS3") then
    if rs3 == true then
		DisplayRecordedMessage("3Text");
	end
  end
end
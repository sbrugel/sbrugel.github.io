-- Anything in green is a comment meant to help you out.

-- true/false defn
FALSE = 0
TRUE = 1

-- condition return values
CONDITION_NOT_YET_MET = 0
CONDITION_SUCCEEDED = 1
CONDITION_FAILED = 2

-- Message types
MT_INFO = 0 
MT_ALERT = 1 

MSG_TOP = 1
MSG_VCENTRE = 2
MSG_BOTTOM = 4
MSG_LEFT = 8
MSG_CENTRE = 16
MSG_RIGHT = 32

MSG_SMALL = 0
MSG_REG = 1
MSG_LRG = 2

function DisplayRecordedMessage( messageName )
  SysCall("RegisterRecordedMessage", "StartDisplay" .. messageName,  
      "StopDisplay" .. messageName, 1);
end

function StartDisplay1()
  SysCall ( "ScenarioManager:ShowInfoMessageExt", "Scenario Info",  
      "1.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_REG, TRUE );
end

function StopDisplay1()
end

function StartDisplay2()
  SysCall ( "ScenarioManager:ShowInfoMessageExt", "Scenario Info",  
      "2.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
end

function StopDisplay2()
end

function StartDisplay3()
  SysCall ( "ScenarioManager:ShowInfoMessageExt", "Scenario Info",  
      "3.html", 0, MSG_VCENTRE + MSG_CENTRE, MSG_SMALL, TRUE );
end

function StopDisplay3()
end

function OnEvent(event)
  if (event == "text1") then
    DisplayRecordedMessage("1");
  end
  if (event == "text2") then
    DisplayRecordedMessage("2");
  end
  if (event == "text3") then
    DisplayRecordedMessage("3");
  end
  if (event == "cabcam") then
    SysCall ( "CameraManager:ActivateCamera", "CabCamera", 0 );
  end
end
require("Assets/AP/Class37Pack01/RailVehicles/Diesel/Class37/CommonResources/Scripts/c37-main-unrefurb.lua")

oldUpdate = Update
oldInit = Initialise

function Initialise()
	oldInit()
	Call("BeginUpdate")
end

function Update(t)
	WIPAC_Head()
	WIPAC_Marker()
	WIPAC_Tail()
	
	oldUpdate(t)
end

function WIPAC_Head()

	cab1HLSwitch = math.floor(getcontrol("Cab1HeadlightSwitch"))
	cab2HLSwitch = math.floor(getcontrol("Cab2HeadlightSwitch"))

	if cab1HLSwitch == 0 then
		Call("WIPACLights:ActivateNode", "headlightL", 0)
		Call("WIPACLights:ActivateNode", "headlightR", 0)
	elseif cab1HLSwitch == 1 then
		Call("WIPACLights:ActivateNode", "headlightL", 1)
		Call("WIPACLights:ActivateNode", "headlightR", 0)
	end
	-- need to create bin file for second set of lights
	if cab2HLSwitch == 0 then
		Call("WIPACLights2:ActivateNode", "headlightL", 0)
		Call("WIPACLights2:ActivateNode", "headlightR", 0)
	elseif cab2HLSwitch == 1 then
		Call("WIPACLights2:ActivateNode", "headlightL", 1)
		Call("WIPACLights2:ActivateNode", "headlightR", 0)
	end
end

function WIPAC_Marker()
	cab1MLSwitch = math.floor(getcontrol("Cab1RouteIndicatorSwitch"))
	
	if cab1MLSwitch == 0 then
		Call("WIPACLights:ActivateNode", "marker", 0)
		Call("Beacon:ActivateNode", "marker", 0)
	else
		Call("WIPACLights:ActivateNode", "marker", 1)
		Call("Beacon:ActivateNode", "marker", 1)
	end
	
	cab2MLSwitch = math.floor(getcontrol("Cab2RouteIndicatorSwitch"))
	
	if cab2MLSwitch == 0 then
		Call("WIPACLights2:ActivateNode", "marker", 0)
		Call("Beacon2:ActivateNode", "marker", 0)
	else
		Call("WIPACLights2:ActivateNode", "marker", 1)
		Call("Beacon2:ActivateNode", "marker", 1)
	end
end

function WIPAC_Tail()
	cab1TLSwitchA = math.floor(getcontrol("Cab1TaillightASwitch"))
	cab1TLSwitchB = math.floor(getcontrol("Cab1TaillightBSwitch"))
	
	if cab1TLSwitchA == 0 then
		Call("WIPACLights:ActivateNode", "tailL", 0)
	elseif cab1TLSwitchA == 1 then
		Call("WIPACLights:ActivateNode", "tailL", 1)
	end
	
	if cab1TLSwitchB == 0 then
		Call("WIPACLights:ActivateNode", "tailR", 0)
	elseif cab1TLSwitchB == 1 then
		Call("WIPACLights:ActivateNode", "tailR", 1)
	end
	
	cab2TLSwitchA = math.floor(getcontrol("Cab2TaillightASwitch"))
	cab2TLSwitchB = math.floor(getcontrol("Cab2TaillightBSwitch"))
	
	if cab2TLSwitchA == 0 then
		Call("WIPACLights2:ActivateNode", "tailL", 0)
		Call("WIPACLights2:ActivateNode", "tailL", 1)
	elseif cab2TLSwitchA == 1 then
		Call("WIPACLights2:ActivateNode", "tailL", 1)
		Call("WIPACLights2:ActivateNode", "tailL", 0)
	end
	
	if cab2TLSwitchB == 0 then
		Call("WIPACLights2:ActivateNode", "tailR", 0)
		Call("WIPACLights2:ActivateNode", "tailR", 1)
	elseif cab2TLSwitchB == 1 then
		Call("WIPACLights2:ActivateNode", "tailR", 1)
		Call("WIPACLights2:ActivateNode", "tailR", 0)
	end
end

function getcontrol (name)

	if Call( "*:ControlExists", name, 0 ) then
		return Call( "*:GetControlValue", name, 0 )
	else
		return 0
	end

end
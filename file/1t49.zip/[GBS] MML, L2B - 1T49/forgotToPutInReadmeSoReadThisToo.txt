Forgot to put this in the readme...

But you will also require South London to Brighton from the Steam Workshop. (part 2 only)

Apologies, and happy driving! :^)